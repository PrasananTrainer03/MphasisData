package g1.ServiceDemo;

public class Calc {

	public int sum(int a,int b) {
		return a+b;
	}
	
	public int sub(int a,int b) {
		return a-b;
	}
	
	public int mult(int a,int b) {
		return a*b;
	}
}
