public class P33 {
    public static void main(String[] args) {
        String s = "Hello";
        s.concat("World");
        System.out.println(s);
        String p = "I";
        p=p + " Like ";
        p=p + " Java";
        System.out.println(p);
    }
}