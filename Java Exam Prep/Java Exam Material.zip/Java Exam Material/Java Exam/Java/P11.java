import java.util.List;
import java.util.ArrayList;

public class P11 {
    public static void main(String[] args) {
        List alist = new ArrayList();
        alist.add("niru");
        alist.add("pav");
        alist.add("sahil");
        alist.add("malar");
        for (Object ob : alist)
{
    System.out.println(ob);
}        
    }
}