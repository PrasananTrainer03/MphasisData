public class P8 {
    public static void temp() {
       float sum =21;
        // return --sum;
        System.out.println(sum);

    }

    public static void main(String[] args) {
        temp();
    }
}