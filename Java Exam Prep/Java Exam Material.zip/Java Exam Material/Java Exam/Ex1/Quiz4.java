public class Quiz4 {
    public static void main(String[] args) {
        test(101); 
    }

    public static void test(Object ob) {
        System.out.println("Object " +ob);
    }    

    // public static void test(int ob) {
    //     System.out.println("int " +ob);
    // }

    public static void test(Integer ob) {
        System.out.println("Integer " +ob);
    }
}