public class Quiz14 {
    public static void main(String[] args) {
        test(101); 
        test(new Integer(101));
    
      }
    
    // public static void test(Object iObject) {
    //     System.out.println("Object =" + iObject);
    //   }
    
      public static void test(float iValue) {
        System.out.println("int=" + iValue);
      }
}