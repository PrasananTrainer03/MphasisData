public class Quiz18 {
    int x;
    public static void main(String[] args) {
        System.out.println(new Quiz18().x);
    }
}

