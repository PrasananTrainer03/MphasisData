public class P61 {
    public static void main(String[] args) {
        try {
           int a =5;
           int b=0;
           int c=b/a;
           System.out.println("Hello");
        } finally {
            System.out.println("World...");
        }

    }
}