public class P14 {
    public static void main(String[] args) {
        String arr[] =new String[]{"Divya","Fantasy"};
        String a="Divya";
        System.out.println(a.equals(arr[0]));
    }
}