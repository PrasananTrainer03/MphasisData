public class P60 {
    public static void main(String[] args) {
        try {
           int a =5;
           int b=0;
           int c=b/a;
           System.out.println("Hello");
        } catch(Exception e) {
            System.out.println("World...");
        }

    }
}