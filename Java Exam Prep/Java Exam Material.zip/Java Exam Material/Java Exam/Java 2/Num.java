public class Num {
    public static void main(String[] args) {
        
            int x =Integer.parseInt("1d23");
            System.out.println(x);
    }
}