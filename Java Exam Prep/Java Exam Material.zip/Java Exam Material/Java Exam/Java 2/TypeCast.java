public class TypeCast {
    public static void main(String[] args) {
        byte b=6;
        int i =b;

        byte c =i;
        System.out.println(c);

    }
}