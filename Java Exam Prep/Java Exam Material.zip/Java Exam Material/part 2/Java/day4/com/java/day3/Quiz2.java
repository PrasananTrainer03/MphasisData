package com.java.day3;

public class Quiz2 {
    public static void main(String[] args) {
        boolean flag;
        System.out.println(flag);
    }
}