package com.java.day3;

public enum Status {
    BOOKED, PENDING, WAITINGLIST
}