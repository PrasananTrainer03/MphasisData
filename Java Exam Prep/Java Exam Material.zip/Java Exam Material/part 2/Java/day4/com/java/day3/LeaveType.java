package com.java.day3;

public enum LeaveType {
    EL, SL, SSL
}