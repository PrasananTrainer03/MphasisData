package com.java.day3;

public enum LeaveStatus {
    PENDING, APPROVED, REJECTED
}