package com.java.day1;

public class Prog1 {
    public static void main(String[] args) {
        String topic = "Java Training";
        String trainer = "Prasanna";
        // System.out.println("Trainer is " +trainer);
        // System.out.println("Topic is  " +topic);
        System.out.println("Trainer is " +trainer+ " Topic is " +topic);
    }
}