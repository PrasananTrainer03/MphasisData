package com.java.day2;

public class Quiz2 {
    public void show() {
        String s1="Hello";
        s1.concat(" World");
        System.out.println(s1);
    }
    public static void main(String[] args) {
        Quiz2 obj = new Quiz2();
        obj.show();
    }
}