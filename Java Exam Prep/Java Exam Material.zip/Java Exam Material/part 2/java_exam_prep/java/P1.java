public class P1 {
    public static void main(String[] args) {
        int i=10;
       // int j=i++;
       int j = ++i;
        System.out.println(i + " " +j);
    }
}