public class P26 {
    public static void main(String[] args) {
        System.out.println(3+8 + "5");
        System.out.println(8 + "5 + 3");
        System.out.println((3+8) + "5");

        // System.out.println("5" +3+8);
        // System.out.println("5 + 3" +8);
       
    }
}