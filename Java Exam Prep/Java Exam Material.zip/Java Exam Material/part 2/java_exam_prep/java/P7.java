public class P7 {
    public static void main(String[] args) {
        double d = 140.04;
        long l = (long)d;  
        int i = (int)l;	
        byte b =(byte)d;
        //long p =d;
        long p =(long)d;
  
        System.out.println("Double value "+d);
        System.out.println("Long value "+l);
        System.out.println("Int value "+i);
        System.out.println("Byte value "+b);
    }
}