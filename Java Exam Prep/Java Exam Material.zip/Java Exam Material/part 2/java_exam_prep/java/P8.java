public class P8 {
    public static void main(String[] args) {
        try {
            return ;
        } catch(Exception e) {
            System.out.println("Hi");
        } finally {
            System.out.println("Finally");
        }
    }
}