public class P24 {
    int x;
    public static void main(String[] args) {
        System.out.println(new P24().x);
    }
}