/**
 * 
 */

NoOfQuestions = 5;

var questions = [
	"1. What is Capital of Equador",
	"2. Who Invented Amiba",
	"3. How many times Cricket Worldcup happpend",
	"4. How Many Wickets Muralidharan taken",
	"5. Who retired from Cricket in 2021"
]

i=0

function load() {
	document.getElementById("question").innerHTML=questions[i];
}

function nextQuestion() {
	i++;
	if (i==5) {
		alert("Exam Over...");
		return;
	}
	load();
}