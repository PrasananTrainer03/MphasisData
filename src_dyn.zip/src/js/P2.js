/**
 * 
 */
function hari() {
		alert("Hi I am Hari...");
	}
	function panchali() {
		alert("Hi I am Panchali...");
	}
	function aditya() {
		alert("Hi I am Aditya...");
	}